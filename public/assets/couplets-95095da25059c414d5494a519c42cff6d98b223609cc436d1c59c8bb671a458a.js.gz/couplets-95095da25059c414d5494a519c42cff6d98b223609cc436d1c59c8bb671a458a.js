$('#couplet_couplet').click(function(){
	$('#keyboard').getkeyboard().reveal();
});
